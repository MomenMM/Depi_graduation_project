package autoex_Test.test_1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SubCart {
	
	WebDriver driver = new ChromeDriver();
	String URL = "https://automationexercise.com/";
	
	
  @Test (priority = 1)
  public void openVrify() {
	  String title = driver.getTitle();
	  assertEquals(title,"Automation Exercise");
  }
  
  @Test (priority = 2)
  public void subInCart() {
	  
	  WebElement cartBtn = driver.findElement(By.cssSelector("#header > div > div > div > div.col-sm-8 > div > ul > li:nth-child(3) > a"));
	  cartBtn.click();
	  String title = driver.getTitle();
	  assertEquals(title,"Automation Exercise - Checkout");
	  
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0,document.body.scrollHeight)", "");
	  String Sub = driver.findElement(By.cssSelector("#footer > div.footer-widget > div > div > div.col-sm-3.col-sm-offset-1 > div > h2")).getText();
	  assertEquals("Subscription".toLowerCase(), Sub.toLowerCase());
	  
	  WebElement mailTxt = driver.findElement(By.id("susbscribe_email"));
	  WebElement sendBtn = driver.findElement(By.id("subscribe"));
	  mailTxt.sendKeys("ahmed.ssa@hotmail.com");
	  sendBtn.click();
	  String succMsg = driver.findElement(By.id("success-subscribe")).getText();
	  assertEquals(succMsg.toLowerCase(), "You have been successfully subscribed!".toLowerCase());
  }
  
  @BeforeTest
  public void openBrowser() {
	  driver.navigate().to(URL);
  }

  @AfterTest
  public void closeBrowser() {
	  driver.close();
  }

}
