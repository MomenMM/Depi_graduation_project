package autoex_Test.test_1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class AddToCart {
	
	WebDriver driver = new ChromeDriver();
	String URL = "https://automationexercise.com/";
	
	
  @Test (priority = 1)
  public void openVrify() {
	  String title = driver.getTitle();
	  assertEquals(title,"Automation Exercise");
  }
  
  @Test (priority = 2)
  public void searchProduct() throws InterruptedException {
	  
	  WebElement productBtn = driver.findElement(By.cssSelector("#header > div > div > div > div.col-sm-8 > div > ul > li:nth-child(2) > a"));
	  productBtn.click();
	  String title = driver.getTitle();
	  assertEquals(title,"Automation Exercise - All Products");
	  driver.findElement(By.xpath("//a[@data-product-id='1']")).click();
	  Thread.sleep(1000);
	  driver.findElement(By.xpath("//button[text()='Continue Shopping']")).click();
	  Thread.sleep(1000);
	  driver.findElement(By.xpath("//a[@data-product-id='2']")).click();
	  Thread.sleep(1000);
	  driver.findElement(By.xpath("//a//u[text()='View Cart']")).click();

	  title = driver.getTitle();
	  assertEquals(title,"Automation Exercise - Checkout");
	  
	  WebElement p1 = driver.findElement(By.id("product-1"));
	  WebElement p2 = driver.findElement(By.id("product-2"));

	  assertTrue(p1.getText().toLowerCase().contains("Blue Top".toLowerCase()));
	  assertTrue(p2.getText().toLowerCase().contains("Men Tshirt".toLowerCase()));
	  
	  assertTrue(p1.getText().toLowerCase().contains("500"));
	  assertTrue(p2.getText().toLowerCase().contains("400"));
	  
	  assertTrue(p1.getText().toLowerCase().contains("1"));
	  assertTrue(p2.getText().toLowerCase().contains("1"));
	  
	  assertTrue(p1.getText().toLowerCase().contains("500"));
	  assertTrue(p2.getText().toLowerCase().contains("400"));

  }
  
  @BeforeTest
  public void openBrowser() {
	  driver.navigate().to(URL);
  }

  @AfterTest
  public void closeBrowser() {
	  driver.close();
  }

}
