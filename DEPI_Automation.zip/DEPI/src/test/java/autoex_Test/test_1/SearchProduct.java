package autoex_Test.test_1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SearchProduct {
	
	WebDriver driver = new ChromeDriver();
	String URL = "https://automationexercise.com/";
	
	
  @Test (priority = 1)
  public void openVrify() {
	  String title = driver.getTitle();
	  assertEquals(title,"Automation Exercise");
  }
  
  @Test (priority = 2)
  public void searchProduct() throws InterruptedException {
	  
	  WebElement productBtn = driver.findElement(By.cssSelector("#header > div > div > div > div.col-sm-8 > div > ul > li:nth-child(2) > a"));
	  productBtn.click();
	  String title = driver.getTitle();
	  assertEquals(title,"Automation Exercise - All Products");
	  
	  String Product = driver.findElement(By.cssSelector("body > section:nth-child(3) > div > div > div.col-sm-9.padding-right > div > h2")).getText();
	  assertEquals(Product.toLowerCase(),"All Products".toLowerCase());
	  
	  WebElement searchBtn = driver.findElement(By.id("submit_search"));
	  WebElement searchTxt = driver.findElement(By.id("search_product"));
	  searchTxt.sendKeys("Jeans");
	  searchBtn.click();
	  
	  Product = driver.findElement(By.cssSelector("body > section:nth-child(3) > div > div > div.col-sm-9.padding-right > div > h2")).getText();
	  assertEquals(Product.toLowerCase(),"Searched Products".toLowerCase());

	  
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("window.scrollTo(0, document.body.scrollHeight / 2);");
//	  Thread.sleep(3000);
	  
	  List<WebElement> products = driver.findElements(By.className("productinfo"));
	  
	  for (WebElement p : products) {

		  assertTrue(p.getText().toLowerCase().contains("Jeans".toLowerCase()));
	  }
  }
  
  @BeforeTest
  public void openBrowser() {
	  driver.navigate().to(URL);
  }

  @AfterTest
  public void closeBrowser() {
	  driver.close();
  }

}
