package momenAutomation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertEquals; 

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import java.time.Duration;


public class ScrollingToTheTop { 

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
    String URL = "https://automationexercise.com/";

    @BeforeTest
    public void openBrowser() {

        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        driver.navigate().to(URL);
    }

    @Test
    public void verifySubscriptionAndScrollUpWithJS() { // Method name updated for clarity
        // 1. Navigate to URL - Done in @BeforeTest
        assertEquals(driver.getTitle(), "Automation Exercise", "Homepage title does not match.");

        // 2. Scroll down to the bottom of the page
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        System.out.println("Scrolled to the bottom of the page.");

        // 3. Verify that "Subscription" heading is visible
        WebElement subscriptionHeading = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//div[@class='single-widget']/h2[normalize-space()='Subscription']")
        ));
        assertTrue(subscriptionHeading.isDisplayed(), "'Subscription' heading is not visible at the bottom.");
        System.out.println("'Subscription' heading is visible.");

        // Verify the existence of the form elements within the subscription widget for robustness
        assertTrue(driver.findElement(By.id("susbscribe_email")).isDisplayed(), "Subscription email input not found.");
        assertTrue(driver.findElement(By.id("subscribe")).isDisplayed(), "Subscription button not found.");
        System.out.println("Subscription form elements (email input and button) are present.");

        // 4. Scroll to the top of the page using JavaScript
        js.executeScript("window.scrollTo(0, 0)"); 
        System.out.println("Scrolled to the top of the page using JavaScript.");

        // 5. Verify that "Full-Fledged practice website for Automation Engineers" is visible at the top of the page
        try {
            Thread.sleep(1000); // Brief pause for scroll animation
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        WebElement topPageTextElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//h2[contains(text(), 'Full-Fledged practice website for Automation Engineers')] | //div[contains(text(), 'Full-Fledged practice website for Automation Engineers')]")
        ));
        assertTrue(topPageTextElement.isDisplayed(), "'Full-Fledged practice website for Automation Engineers' text not visible at the top.");
        System.out.println("'Full-Fledged practice website for Automation Engineers' text is visible at the top.");
        
        System.out.println("Test completed successfully!");
    }

    @AfterTest
    public void closeBrowser() {
      
            driver.quit();
        
    }
}
