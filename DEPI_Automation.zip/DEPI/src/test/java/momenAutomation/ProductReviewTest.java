package momenAutomation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;


public class ProductReviewTest {

    WebDriver driver;
    String URL = "https://automationexercise.com/";

    @BeforeTest
    public void openBrowser() {
 
        driver = new FirefoxDriver();
        driver.manage().window().maximize(); // Maximize browser window
        driver.navigate().to(URL); // Navigate to the base URL
    }


    @Test
    public void submitProductReview() throws InterruptedException {
        // Test case for submitting a product review

        // 1. Click on 'Products' button
        driver.findElement(By.xpath("//a[@href='/products']")).click();
        // Adding a small delay for page load. 
        Thread.sleep(1000); 

        // Verifies the "All Products" header is visible
        WebElement allProductsHeader = driver.findElement(By.xpath("//h2[@class='title text-center' and normalize-space()='All Products']"));
        assertTrue(allProductsHeader.isDisplayed(), "'All Products' header is not visible.");
        // Verifies the title of the "All Products" page
        assertEquals(driver.getTitle(), "Automation Exercise - All Products", "All Products page title does not match.");

        // Locates and clicks the 'View Product' link for product ID 1
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 300);");
        driver.findElement(By.xpath("//a[@href='/product_details/1']")).click();
        Thread.sleep(1000); // Delay for product details page to load

        // 4. Verify 'Write Your Review' is visible
        WebElement writeReviewTab = driver.findElement(By.xpath("//a[@href='#reviews' and normalize-space()='Write Your Review']"));
        assertTrue(writeReviewTab.isDisplayed(), "'Write Your Review' tab is not visible.");

        // 5. Enter name, email and review
        driver.findElement(By.id("name")).sendKeys("hello");
        // Finds the email input field and types "hello@world.com"
        driver.findElement(By.id("email")).sendKeys("hello@world.com");
        // Finds the review textarea and types "wow great product"
        driver.findElement(By.id("review")).sendKeys("wow great product");
        Thread.sleep(500); // Small pause before clicking submit

        // 6. Click 'Submit' button
        driver.findElement(By.id("button-review")).click();
        Thread.sleep(1000); // Delay for the success message to appear

        // 7. Verify success message 'Thank you for your review.' is visible
        
        WebElement successMessage = driver.findElement(By.xpath("//div[@id='review-section']//span[normalize-space(text())='Thank you for your review.']"));
        assertTrue(successMessage.isDisplayed(), "Success message 'Thank you for your review.' is not visible.");
        assertEquals(successMessage.getText().trim(), "Thank you for your review.", "Success message text does not match.");
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit(); // quit() closes all windows and terminates the session
    }
}
