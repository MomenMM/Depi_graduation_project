package Autoamtion_Project.Automation_Excericse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ProductPage extends PageBase {
  
    @FindBy(xpath = "(//div[@class='productinfo text-center'])[1]")
    WebElement firstProductOverlay;
 
    @FindBy(xpath = "(//div[@class='productinfo text-center']//a[@class='btn btn-default add-to-cart'])[1]")
    WebElement firstProductAddToCartButton;

    
    @FindBy(xpath = "//div[@class='modal-content']//u[normalize-space()='View Cart']")
    WebElement viewCartModalLink;

    
    @FindBy(css = ".brands_products")
    WebElement brandsSection;

    
    @FindBy(css = ".brands_products a")
    List<WebElement> brandLinks;

    
    @FindBy(id = "search_product")
    WebElement searchInput;

    
    @FindBy(id = "submit_search")
    WebElement searchButton;

   
    @FindBy(xpath = "//h2[@class='title text-center' and text()='All Products']")
    WebElement allProductsTitle;

   
    @FindBy(xpath = "//h2[@class='title text-center' and text()='Searched Products']")
    WebElement searchedProductsTitle;

     
    @FindBy(css = ".features_items .productinfo")
    List<WebElement> productItems;


    public ProductPage(WebDriver driver) {
    	
        super(driver); 
        
    }

    public void hoverAndAddFirstProductToCart() {
        Actions actions = new Actions(this.driver);

        
        wait.until(ExpectedConditions.visibilityOf(firstProductOverlay));
        
        actions.moveToElement(firstProductOverlay).perform();

        wait.until(ExpectedConditions.elementToBeClickable(firstProductAddToCartButton));
        
        firstProductAddToCartButton.click();

       
        wait.until(ExpectedConditions.elementToBeClickable(viewCartModalLink));
    }

    public CartPage clickViewCart() {
        
        wait.until(ExpectedConditions.elementToBeClickable(viewCartModalLink));
        
        viewCartModalLink.click();
        
        return new CartPage(driver); 
        
    }

    
    public boolean isBrandsSectionVisible() {
        try {
            
            wait.until(ExpectedConditions.visibilityOf(brandsSection));
            return brandsSection.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public BrandPage clickBrand(String brandName) {
        WebElement targetBrandLink = null;
        
        for (WebElement link : brandLinks) {
           
            String extractedBrandName = extractBrandName(link.getText());
            
            if (extractedBrandName.trim().equalsIgnoreCase(brandName.trim())) {
                targetBrandLink = link;
                break; 
            }
        }

        if (targetBrandLink != null) {
            
            wait.until(ExpectedConditions.elementToBeClickable(targetBrandLink));
            targetBrandLink.click();
           
            return new BrandPage(driver);
        } else {
            
            throw new org.openqa.selenium.NoSuchElementException("Brand link with text '" + brandName + "' not found in the brands list.");
        }
    }

    public List<String> getBrandNames() {
    	
        List<String> names = new ArrayList<>();
        
        wait.until(ExpectedConditions.visibilityOfAllElements(brandLinks));
        
        for (WebElement link : brandLinks) {
            
            names.add(extractBrandName(link.getText()));
            
        }
        
        return names;
        
    }

    
    private String extractBrandName(String linkText) {
        
        Pattern pattern = Pattern.compile("\\s*\\(\\d+\\)\\s*");
        Matcher matcher = pattern.matcher(linkText);
        String brandName = matcher.replaceAll("");
        return brandName.trim(); 
    }

    public boolean isAllProductsTitleVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(allProductsTitle));
            return allProductsTitle.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void enterSearchInput(String productName) {
        wait.until(ExpectedConditions.visibilityOf(searchInput));
        searchInput.sendKeys(productName);
    }

    public void clickSearchButton() {
        wait.until(ExpectedConditions.elementToBeClickable(searchButton));
        searchButton.click();
    }

    public boolean isSearchedProductsTitleVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(searchedProductsTitle));
            return searchedProductsTitle.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public List<WebElement> getDisplayedProducts() {
        
        wait.until(ExpectedConditions.visibilityOfAllElements(productItems));
        return productItems;
    }

    public void addAllDisplayedProductsToCart() {
        Actions actions = new Actions(driver);
        List<WebElement> products = getDisplayedProducts(); 

        if (products.isEmpty()) {
            System.out.println("No products found to add to cart.");
            return;
        }

        for (int i = 0; i < products.size(); i++) {
            WebElement product = products.get(i);
            
            WebElement addToCartButton = product.findElement(By.xpath(".//a[@class='btn btn-default add-to-cart']"));

            
            actions.moveToElement(product).perform();

           
            wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));

           
            addToCartButton.click();

             try {
                 WebElement continueShoppingButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Continue Shopping']")));
                 continueShoppingButton.click();
             } catch (Exception e) {
                 
                 System.out.println("Could not click 'Continue Shopping' button or modal did not appear as expected after adding product " + (i+1));
             }

           
             try {
                 Thread.sleep(500); 
             } catch (InterruptedException e) {
                 e.printStackTrace();
             }
        }
    }
}
