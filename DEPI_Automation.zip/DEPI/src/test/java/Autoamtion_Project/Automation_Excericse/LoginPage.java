package Autoamtion_Project.Automation_Excericse;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class LoginPage extends PageBase {

   
    public LoginPage(WebDriver driver) {
        super(driver);
        
    }

    @FindBy(name="email")
    WebElement emailTxt;

    
    @FindBy(name="password")
    WebElement passwordTxt;

  
    @FindBy(xpath="//button[@data-qa='login-button']")
    WebElement loginBtn;

   
    @FindBy(xpath="//*[@id=\"form\"]/div/div/div[1]/div/h2")
    public WebElement loginMessage;

    
    @FindBy(linkText = "Logout")
    public WebElement logoutBtn;

   
    @FindBy(xpath="//*[@id=\"form\"]/div/div/div[1]/div[1]/form/p")
    public WebElement failedMessage;

    
    @FindBy(xpath = "//input[@data-qa='signup-name']")
    WebElement signupNameInput;

    @FindBy(xpath = "//input[@data-qa='signup-email']")
    WebElement signupEmailInput;

    @FindBy(xpath = "//button[@data-qa='signup-button']")
    WebElement signupButton;

    public void enterLoginEmail(String email) {
        wait.until(ExpectedConditions.visibilityOf(emailTxt)); 
        emailTxt.sendKeys(email);
    }

    public void enterLoginPassword(String password) {
        wait.until(ExpectedConditions.visibilityOf(passwordTxt)); 
        passwordTxt.sendKeys(password);
    }

    public HomePage clickLoginButton() {
        wait.until(ExpectedConditions.elementToBeClickable(loginBtn)); 
        loginBtn.click();
        
        return new HomePage(driver); 
    }

    public HomePage userCanLogin(String email, String password) {
        enterLoginEmail(email);
        enterLoginPassword(password);
        return clickLoginButton(); 
    }

    public void userCanLogout() {
        wait.until(ExpectedConditions.elementToBeClickable(logoutBtn)); 
        logoutBtn.click();
        
    }

   
    public boolean isLoginFormVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(emailTxt)); 
            return emailTxt.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

 
    public boolean isLoginMessageVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(loginMessage));
            return loginMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

   
    public boolean isFailedMessageVisible() {
         try {
            wait.until(ExpectedConditions.visibilityOf(failedMessage)); 
            return failedMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

   
}
