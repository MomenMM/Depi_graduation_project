package Autoamtion_Project.Automation_Excericse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends PageBase {

   
    @FindBy(xpath = "//a[contains(text(), 'Products')]")
    WebElement productsButton;

    @FindBy(xpath = "//a[contains(text(), ' Cart')]")
    WebElement cartButton;

    @FindBy(xpath = "//a[contains(text(), ' Signup / Login')]")
    WebElement signupLoginButton;

    @FindBy(id = "accordian") 
    WebElement categorySection;

    @FindBy(xpath = "//a[contains(@href, '#Women')]")
    WebElement womenCategoryLink;

    @FindBy(xpath = "//div[@id='Women']//a[contains(text(), 'Dress')]")
    WebElement womenDressSubCategoryLink;

     @FindBy(xpath = "//a[contains(@href, '#Men')]")
    WebElement menCategoryLink;

    @FindBy(xpath = "//div[@id='Men']//a[contains(text(), 'Jeans')]")
    WebElement menJeansSubCategoryLink;

    public HomePage(WebDriver driver) {
        super(driver);
    }
     
    public boolean isHomePageVisible() {
        
        try {
             wait.until(ExpectedConditions.visibilityOf(productsButton));
             return productsButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }


    public ProductPage clickProducts() {
        wait.until(ExpectedConditions.elementToBeClickable(productsButton));
        productsButton.click();
        
        return new ProductPage(driver);
    }

    public CartPage clickCart() {
        wait.until(ExpectedConditions.elementToBeClickable(cartButton));
        cartButton.click();
        
        return new CartPage(driver);
    }
    
    public LoginPage clickSignupLogin() {
        wait.until(ExpectedConditions.elementToBeClickable(signupLoginButton));
        signupLoginButton.click();
       
        return new LoginPage(driver);
    }


    public boolean isCategorySectionVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(categorySection));
            return categorySection.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

   
    public void expandWomenCategory() {
        wait.until(ExpectedConditions.elementToBeClickable(womenCategoryLink));
        womenCategoryLink.click();
    }

    public CategoryPage clickWomenSubCategory(String subCategoryName) {
        
        WebElement subCategoryLink = driver.findElement(By.xpath("//div[@id='Women']//a[contains(text(), '" + subCategoryName + "')]"));
        wait.until(ExpectedConditions.elementToBeClickable(subCategoryLink));
        subCategoryLink.click();
        return new CategoryPage(driver);
    }

    public void expandMenCategory() {
        wait.until(ExpectedConditions.elementToBeClickable(menCategoryLink));
        menCategoryLink.click();
    }

    public CategoryPage clickMenSubCategory(String subCategoryName) {
       
        WebElement subCategoryLink = driver.findElement(By.xpath("//div[@id='Men']//a[contains(text(), '" + subCategoryName + "')]"));
        wait.until(ExpectedConditions.elementToBeClickable(subCategoryLink));
        subCategoryLink.click();
        return new CategoryPage(driver);
    }

}
