package Autoamtion_Project.Automation_Excericse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.List;
import java.util.ArrayList;


public class CartPage extends PageBase {

    
    @FindBy(id = "cart_info_table")
    WebElement cartTable;

    
    @FindBy(css = "#cart_info_table tbody tr")
    List<WebElement> cartItems;

    public CartPage(WebDriver driver) {
    	
        super(driver); 
    }

   
    public boolean isCartTableVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(cartTable));
            return cartTable.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isProductInCart() {
        try {
            
            wait.until(ExpectedConditions.visibilityOfAllElements(cartItems));
            return !cartItems.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isCartEmpty() {
         try {
             
             wait.until(ExpectedConditions.invisibilityOfAllElements(cartItems));
             return cartItems.isEmpty(); 
         } catch (Exception e) {
             
             return false;
         }
    }

    public void clickDelete() {
        
        WebElement firstItemDeleteButton = driver.findElement(By.cssSelector("#cart_info_table tbody tr:first-child .cart_quantity_delete"));
        wait.until(ExpectedConditions.elementToBeClickable(firstItemDeleteButton));
        firstItemDeleteButton.click();
        
        wait.until(ExpectedConditions.invisibilityOf(firstItemDeleteButton)); 
    }

    public boolean isProductPresentInCart(String productName) {
        boolean found = false;
        
        wait.until(ExpectedConditions.visibilityOfAllElements(cartItems));

        for (WebElement item : cartItems) {
           
            try {
                WebElement productNameElement = item.findElement(By.xpath(".//td[@class='cart_description']/h4/a"));
                if (productNameElement.getText().trim().equalsIgnoreCase(productName.trim())) {
                    found = true;
                    break; 
                }
            } catch (org.openqa.selenium.NoSuchElementException e) {
               
            }
        }
        return found;
    }

    public List<String> getProductNamesInCart() {
        List<String> productNames = new ArrayList<>();
         
        wait.until(ExpectedConditions.visibilityOfAllElements(cartItems));

        for (WebElement item : cartItems) {
            try {
                WebElement productNameElement = item.findElement(By.xpath(".//td[@class='cart_description']/h4/a")); 
                productNames.add(productNameElement.getText().trim());
            } catch (org.openqa.selenium.NoSuchElementException e) {
                
            }
        }
        return productNames;
    }
}
