package Autoamtion_Project.Automation_Excericse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class CategoryPage {

    private WebDriver driver;
    private WebDriverWait wait;

    private By categoryTitle = By.cssSelector(".title.text-center");

    public CategoryPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void verifyCategoryTitle(String expectedTitle) {
        WebElement titleElement = wait.until(ExpectedConditions.visibilityOfElementLocated(categoryTitle));
        String actualTitleFromPage = titleElement.getText().trim();
        String expectedTitleFromTest = expectedTitle.trim();

        // Normalize both titles by replacing varied spaces around a hyphen with a single hyphen
        // e.g., "TEXT -  SUBTEXT" becomes "TEXT-SUBTEXT"
        String normalizedActualTitle = actualTitleFromPage.replaceAll("\\s*-\\s*", "-");
        String normalizedExpectedTitle = expectedTitleFromTest.replaceAll("\\s*-\\s*", "-");

        Assert.assertEquals(normalizedActualTitle, normalizedExpectedTitle,
                "Category title mismatch after normalizing spaces around hyphen. " +
                "Original expected: '" + expectedTitleFromTest + "', " +
                "Original actual from page: '" + actualTitleFromPage + "'");
    }

    public boolean isCategoryTitleDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(categoryTitle));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}