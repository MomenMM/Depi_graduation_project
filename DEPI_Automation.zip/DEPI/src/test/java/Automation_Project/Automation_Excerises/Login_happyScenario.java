package Automation_Project.Automation_Excerises;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
public class Login_happyScenario extends TestBase {

  // Creating page object 
  HomePage homeObject = new HomePage(driver);
 LoginPage loginObject = new LoginPage(driver);
  RegisterPage registerObject;

  @Test(priority = 1)
  public void correctUsernameAndPassword() throws InterruptedException {
   // Open the login page from the homepage
    homeObject.openLoginPage();

   //  verify the login page appeared correctly
  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
  Assert.assertTrue(loginObject.isLoginButtonVisible(), "Login button is not visible.");
 Assert.assertFalse(loginObject.isLoggedInAsUsernameVisible(), "Logged in message is visible before logging in!");

  //  Login with correct email and password
 loginObject.userCanLogin("Menna4@gmai.com", "m123");

  //  Confirm the user is now logged in
    Assert.assertTrue(loginObject.isLoggedInAsUsernameVisible(), "Logged in as username message is not visible after login.");

   //Make the RegisterPage ready
  registerObject = new RegisterPage(driver);

    // Wait Delete Account button active then click it
   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/delete_account']"))).click();

    //  Wait ACCOUNT DELETED message appears
  wait.until(ExpectedConditions.visibilityOfElementLocated(
     By.xpath("//h2[@data-qa='account-deleted']/b[text()='Account Deleted!']")));
  System.out.println("Account Deleted! message verified.");

   //  Click Continue button 
     driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();
    }
}
