package Automation_Project.Automation_Excerises;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class TestBase {
    WebDriver driver = new FirefoxDriver();  
    String baseURL = "https://automationexercise.com/";  // Define the base URL

    @BeforeTest
    public void openBrowser() {
   driver.manage().window().maximize();  // Maximize the browser window
   driver.navigate().to(baseURL);  // Navigate to the base URL
    }

    @AfterTest
    public void closeBrowser() {
        driver.close();  // Close the browser after the test
    }
}
