package Automation_Project.Automation_Excerises;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import java.time.Duration;
public class Register_HappyScenario extends TestBase {

  HomePage homeObject;
  RegisterPage registerObject; 
    @BeforeMethod
    public void setupPages() {
    homeObject = new HomePage(driver);
   registerObject = new RegisterPage(driver);
    }

   @Test
 public void testRegister_NewUserName_MandatoryAndOptional() throws InterruptedException {
 Thread.sleep(2000);
  // Open the signup page
homeObject.signUpBtn.click();
Thread.sleep(2000);
//Verify that theSign Up/Login button is visible
 Assert.assertTrue(homeObject.signUpBtn.isDisplayed(), "Sign Up/Login   button is not visible.");
Thread.sleep(2000);
 // Register a new user
 registerObject.userCanRegister("Menna", "Mennaaaaaaa@gmail.com");
        // Enter account information
     registerObject.enterAccountInformation(
       "m345@", 6, "2", "2003",
       "Mennallah", "abdalmoaty", "canonical", "123 Street",
       "India", "Giza", "6october", "15745",
      "01158078778"
        );
 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
 //Wait for the successmessage after registration
 WebElement successMessage = wait.until(ExpectedConditions.visibilityOf(registerObject.successMesssage));

//Check if the success message matches 'Account Created
        Assert.assertTrue(successMessage.getText().equalsIgnoreCase("Account Created!"),
                "The success message is not as expected. expected [Account Created!] but found [" + successMessage.getText() + "]");

   // Click Continue
     driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();

     // Wait until 'Delete Account' button is clickable and click it
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/delete_account']"))).click();

        // Wait for ACCOUNT DELETED message appear and verify it
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-qa='account-deleted']/b[text()='Account Deleted!']")));
        System.out.println("Account Deleted! message verified.");

        // Click 'Continue
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();
    }
}
