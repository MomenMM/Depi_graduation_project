package Automation_Project.Automation_Excerises;

import org.testng.Assert;
import org.testng.annotations.Test;
public class Logout extends TestBase {
  HomePage homeObject = new HomePage(driver);
  LoginPage loginObject = new LoginPage(driver);
    @Test(priority = 1)
 public void correctUsernameAndPassword() throws InterruptedException {
  // Open the login page
 homeObject.openLoginPage();
  // verify the login page appears correctly
  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
 Assert.assertTrue(loginObject.isLoginButtonVisible(), "Login button is not visible.");
  Assert.assertFalse(loginObject.isLoggedInAsUsernameVisible(), "Logged in as username is already visible before login.");

  // login with correct email and password
 loginObject.userCanLogin("meno318@gmai.com", "mm");

  // verify user is logged in successfully
  Assert.assertTrue(loginObject.isLoggedInAsUsernameVisible(), "Logged in as username is not visible after login.");

  //   verify logout button is displayed
  Assert.assertTrue(loginObject.logoutBtn.isDisplayed(), "Logout button is not displayed.");

 //  logout
        loginObject.userCanLogout();
    }
}
