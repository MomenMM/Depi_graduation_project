package Automation_Project.Automation_Excerises;

import Automation_Project.Automation_Excerises.ContactUsPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class ContactUsTest {

   WebDriver driver; // WebDriver instance to interact with the browser
   ContactUsPage contactUsPage; // Instance of the ContactUsPage class to interact with the contact page

    // Set up method to initialize the WebDriver and open the contact us page before the test class runs
    @BeforeClass
    public void setUp() {
      driver = new ChromeDriver(); // Initialize the Chrome WebDriver
      driver.manage().window().maximize(); // Maximize the browser window
      driver.get("https://automationexercise.com/contact_us"); // Navigate to the Contact Us page
      contactUsPage = new ContactUsPage(driver); // Initialize the ContactUsPage object
    }

    // Test method to verify that the user can successfully submit the contact form
    @Test
    public void testUserCanContactUsSuccessfully() {
        // Call the method from ContactUsPage to fill out the form and submit it
        contactUsPage.userCanContactUs("Doha", "doha@gmail.com", "Automation Test", "This is a test message from Doha.");
        
        // Verify if the success message appears after form submission
        Assert.assertTrue(contactUsPage.contactUsMessage.isDisplayed(), "Contact message is not displayed!");
    }

    // Clean up method to close the browser after the test class completes
    @AfterClass
    public void CloseBrowser() {
        driver.quit(); // Close the browser and quit the WebDriver session
    }
}
