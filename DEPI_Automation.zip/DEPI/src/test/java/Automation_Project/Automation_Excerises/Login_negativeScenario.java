package Automation_Project.Automation_Excerises;
import org.testng.Assert;
import org.testng.annotations.Test;
@Test
public class Login_negativeScenario extends TestBase {
  HomePage homeObject = new HomePage(driver);
  LoginPage loginObject = new LoginPage(driver);
   // Test for incorrect username and password login
  public void incorrectUsernameAndPassword() throws InterruptedException {

 Thread.sleep(1000);
 // Open the login page
 homeObject.openLoginPage();
   Thread.sleep(1000);
   // verify the login page is displayed correctly
  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
  Assert.assertTrue(loginObject.isLoginButtonVisible(), "Login button is not visible.");
  Assert.assertFalse(loginObject.isLoggedInAsUsernameVisible(), "Logged in as username is already visible before login.");

   //  login with incorrect email or password
   loginObject.userCanLogin("menna1284@gmail.com", "mmm");
   Thread.sleep(1000);
     // Check the error message for invalid login
      Assert.assertEquals("Your email or password is incorrect!", loginObject.failedMessage.getText());
      Assert.assertTrue(loginObject.isLoginButtonVisible(), "Login button is not visible after login attempt.");
      Assert.assertFalse(loginObject.isLoggedInAsUsernameVisible(), "Logged in as username is visible after failed login.");
    }
}
