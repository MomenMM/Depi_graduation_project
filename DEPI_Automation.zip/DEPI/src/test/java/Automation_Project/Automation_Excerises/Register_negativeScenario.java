package Automation_Project.Automation_Excerises;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class Register_negativeScenario extends TestBase {

    HomePage homeObject;
    RegisterPage registerObject;

    @BeforeMethod
    public void setupPages() {
        homeObject = new HomePage(driver);
        registerObject = new RegisterPage(driver);
    }
 
    @Test
    public void testRegister_ExistEmail() throws InterruptedException {


        homeObject.openRegisterationPage();
        Thread.sleep(1000);
        
        registerObject.userCanRegister("meno318@gmai.com", "meno318@gmai.com");
        Thread.sleep(1000);

        Assert.assertEquals(registerObject.failedMessage.getText(), "Email Address already exist!");
    }
}
