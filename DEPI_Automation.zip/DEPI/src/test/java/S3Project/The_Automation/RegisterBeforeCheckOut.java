package S3Project.The_Automation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterBeforeCheckOut extends TestBase{
	HomePage homeObject = new HomePage(driver);
ProductsPage productsObject = new ProductsPage(driver); 
CartPage cartObject = new CartPage(driver);
RegisterPage registerObject = new RegisterPage(driver); 
JavascriptExecutor js = (JavascriptExecutor) driver;
  @Test
  public void RegisterBeforeCheckout() throws InterruptedException {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
	  homeObject.openRegisterationPage(); 

	  Assert.assertEquals("New User Signup!", registerObject.newUserMessage.getText());
	 
	  registerObject.userCanRegister("abdonageh123","abdelrahmannageh58000000@gmail.com");
	  
	  Assert.assertEquals("ENTER ACCOUNT INFORMATION", registerObject.enterAccountMessage.getText());
	  
	  registerObject.enterAccountInformation("123456789");
	  js.executeScript("window.scrollBy(0, 150);");
	  registerObject.enterAccountInformationA(1,"10","2003","Abdelrahman","Nageh","Itworx","Zayed","United States");
	  js.executeScript("window.scrollBy(0, 150);");
	 registerObject.enterAccountInformationB("aaaa","bbbb","2164","01012465987");	
	 
	  String success = "Account Created!";
	  Assert.assertEquals(success.toUpperCase(), registerObject.successMesssage.getText());
	  
	  registerObject.continueAccount();
	  
	  Assert.assertEquals("Logged in as abdonageh123", registerObject.loggedInMessage.getText());
	  homeObject.clickViewProduct();
	  Assert.assertTrue(productsObject.isProductDetailPageVisible(), "Product detail page did not open");
	  productsObject.setQuantity(1).clickAddToCart(); 
	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a"))).click();
	  Assert.assertEquals(cartObject.getCartQuantity(),1, "Quantity in cart is not 1");
	  cartObject.clickCheckOut();
	  Assert.assertEquals("Address Details", cartObject.AddressDetailsMsg.getText());
	  cartObject.EnterDescription("Make It Fast");
	  cartObject.clickPlaceOrder();
	  Assert.assertEquals("PaymentOnline payment solutions", cartObject.PaymentMsg.getText());
	  cartObject.EnterPayment("AbdoNageh","86542145","689","05","2029");
	  Thread.sleep(3000);
	  Assert.assertEquals("ORDER PLACED!", cartObject.OrderPlacedMsg.getText());
	  registerObject.deleteAccount();
	  Assert.assertTrue(registerObject.deleteMessage.getText().equalsIgnoreCase("Account Deleted!"));
  }
}
