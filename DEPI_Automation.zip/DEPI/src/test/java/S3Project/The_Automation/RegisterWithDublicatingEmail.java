package S3Project.The_Automation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterWithDublicatingEmail extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ProductsPage productsObject = new ProductsPage(driver); 
	CartPage cartObject = new CartPage(driver);
	RegisterPage registerObject = new RegisterPage(driver); 
	JavascriptExecutor js = (JavascriptExecutor) driver;
  @Test
  public void test_DublicatinEmail() throws InterruptedException {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
	  js.executeScript("window.scrollBy(0, 150);");
	  homeObject.clickViewProduct();
	  Assert.assertTrue(productsObject.isProductDetailPageVisible(), "Product detail page did not open");
	  productsObject.setQuantity(1).clickAddToCart(); 
	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a"))).click();
	  Assert.assertEquals(cartObject.getCartQuantity(),1, "Quantity in cart is not 1");
	  cartObject.clickCheckOut();
	  cartObject.clickRegisterBtn(); 

	  Assert.assertEquals("New User Signup!", registerObject.newUserMessage.getText());
	 
	  registerObject.userCanRegister("abdonageh123","abdelrahmannageh0000@gmail.com");
	  Assert.assertEquals("Email Address already exist!", registerObject.EmailExist.getText());
  }
}