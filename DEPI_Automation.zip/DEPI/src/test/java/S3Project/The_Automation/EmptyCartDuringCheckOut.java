package S3Project.The_Automation;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert; 
import org.testng.annotations.Test;

public class  EmptyCartDuringCheckOut  extends TestBase{
	HomePage homeObject = new HomePage(driver);
ProductsPage productsObject = new ProductsPage(driver); 
CartPage cartObject = new CartPage(driver);
RegisterPage registerObject = new RegisterPage(driver); 
JavascriptExecutor js = (JavascriptExecutor) driver;
  @Test
  public void EmptyCartDuringCheckOut() throws InterruptedException {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
	  homeObject.openRegisterationPage(); 

	  Assert.assertEquals("New User Signup!", registerObject.newUserMessage.getText());
	 
	  registerObject.userCanRegister("abdonageh123","abdelrahmannageh20@gmail.com");
	  
	  Assert.assertEquals("ENTER ACCOUNT INFORMATION", registerObject.enterAccountMessage.getText());
	  
	  registerObject.enterAccountInformation("123456789");
	  js.executeScript("window.scrollBy(0, 150);");
	  registerObject.enterAccountInformationA(1,"10","2003","Abdelrahman","Nageh","Itworx","Zayed","United States");
	  js.executeScript("window.scrollBy(0, 150);");
	 registerObject.enterAccountInformationB("aaaa","bbbb","2164","01012465987");	  
	  
	  js.executeScript("window.scrollBy(0, 150);");
	 
	  String success = "Account Created!";
	  Assert.assertEquals(success.toUpperCase(), registerObject.successMesssage.getText());
	  
	  registerObject.continueAccount();
	  
	  Assert.assertEquals("Logged in as abdonageh123", registerObject.loggedInMessage.getText());
	  homeObject.goToCart();
	  Assert.assertEquals( "Cart is empty!", cartObject.emptyCartMessage.getText());
  }
}
