package S3Project.The_Automation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginWithWrongPassword extends TestBase {
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver); 
	RegisterPage registerObject = new RegisterPage(driver);
  @Test
  public void LoginWithWrongPassword() {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
	  	homeObject.openLoginPage();
	  	Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
	  	loginObject.userCanLogin("abdonageh665@gmail.com", "12345");
	  	Assert.assertEquals("Your email or password is incorrect!", registerObject.PasswordWrongMsg.getText());
  }
}
