package tests;

import Autoamtion_Project.Automation_Excericse.HomePage;
import Autoamtion_Project.Automation_Excericse.CategoryPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class TestCase18 {

    private WebDriver driver;
    private HomePage homePage;
    private WebDriverWait wait;
    private String URL = "https://www.automationexercise.com/";

    @BeforeClass
    public void setUp() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("user-data-dir=C:/temp/chrome-test-profile-tc18-" + System.currentTimeMillis());
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get(URL);

        wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        homePage = new HomePage(driver);
    }

    @Test
    public void viewCategoryProductsAndVerifyTitle() {
        wait.until(ExpectedConditions.urlToBe("https://www.automationexercise.com/"));

        Assert.assertTrue(homePage.isHomePageVisible(), "Home page is not visible.");
        Assert.assertTrue(homePage.isCategorySectionVisible(), "Categories section is not visible on the homepage.");

        homePage.expandWomenCategory();
        CategoryPage womenDressPage = homePage.clickWomenSubCategory("Dress");

        Assert.assertTrue(womenDressPage.isCategoryTitleDisplayed(), "Category title 'WOMEN - DRESS PRODUCTS' is not displayed.");
        womenDressPage.verifyCategoryTitle("WOMEN -  DRESS PRODUCTS");
  
        driver.navigate().to(URL);
        wait.until(ExpectedConditions.urlToBe("https://www.automationexercise.com/")); 
        
        homePage.expandMenCategory();
        CategoryPage menJeansPage = homePage.clickMenSubCategory("Jeans");
       
        Assert.assertTrue(menJeansPage.isCategoryTitleDisplayed(), "Category title 'MEN -  JEANS PRODUCTS' is not displayed.");
        menJeansPage.verifyCategoryTitle("MEN - JEANS PRODUCTS");

        System.out.println("Test Case 18 Passed: Verified category products display.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
