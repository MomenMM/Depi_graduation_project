package tests;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Autoamtion_Project.Automation_Excericse.CartPage;
import Autoamtion_Project.Automation_Excericse.HomePage;
import Autoamtion_Project.Automation_Excericse.ProductPage;

public class TestCase17 {
	
	private WebDriver driver;
    HomePage homePage;
    ProductPage productPage;
    CartPage cartPage;
    private String URL = "https://www.automationexercise.com/";

    @BeforeClass
    public void setUp() {
    	
        ChromeOptions options = new ChromeOptions();
        options.addArguments("user-data-dir=C:/temp/chrome-test-profile-tc17-" + System.currentTimeMillis());
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.navigate().to(URL);
        
        homePage = new HomePage(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
        
    }
    @Test 
    public void removeProductFromCartTest() throws InterruptedException {


       
        homePage.clickProducts(); 
        
       
        productPage.hoverAndAddFirstProductToCart();
        productPage.clickViewCart();

       
        Assert.assertTrue(cartPage.isProductInCart(), "Product was not added to cart.");

        cartPage.clickDelete();

        
        Assert.assertTrue(cartPage.isCartEmpty(), "Product was not removed from cart.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    
}