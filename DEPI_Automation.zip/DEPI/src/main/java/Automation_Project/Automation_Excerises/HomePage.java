package Automation_Project.Automation_Excerises;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

// Base class for all page objects
import Automation_Project.Automation_Excerises.PageBase;

public class HomePage extends PageBase {

    
  public HomePage(WebDriver driver) {
        super(driver);
    }

    //  the 'Signup / Login' button
  @FindBy(linkText = "Signup / Login")
    public WebElement signUpBtn;

    //  the 'Home' link
  @FindBy(linkText = "Home")
    public WebElement homeLink;

    //  the 'Contact us' button
   @FindBy(linkText = "Contact us")
    WebElement contactUsBtn;

    //  'Continue' button 
  @FindBy(css = "#form > div > div > div > div > a")
    public WebElement continueBtn;

    //  open the registration page 
   public void openRegisterationPage() {
        signUpBtn.click();
    }

    //  open the login page 
    public void openLoginPage() {
        signUpBtn.click();
    }

    //  to open the contact page 
    public void openContactPage() {
        contactUsBtn.click();
    }
}
