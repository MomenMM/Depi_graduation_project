package Automation_Project.Automation_Excerises;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
public class PageBase {
    // WebDriver for all page classes
    protected WebDriver driver;
 
    public PageBase(WebDriver driver) {
        this.driver = driver;
     // Initializes all elements in the page class
        PageFactory.initElements(driver, this);
    }
}
