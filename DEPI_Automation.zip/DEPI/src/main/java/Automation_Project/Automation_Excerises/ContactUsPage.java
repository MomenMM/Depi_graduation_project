package Automation_Project.Automation_Excerises;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ContactUsPage extends PageBase {

    // Constructor to initialize WebDriver and call parent constructor
    public ContactUsPage(WebDriver driver) {
        super(driver);
    }
    
    // Locators for the contact form fields
    @FindBy(name="name")
    WebElement nameTxt;
    
    @FindBy(name="email")
    WebElement emailTxt;
    
    @FindBy(name="subject")
    WebElement subjectTxt;
    
    @FindBy(name="message")
    WebElement messageTxt;
    
    @FindBy(name="upload_file")
    WebElement uploadFileBtn;
    
    @FindBy(xpath="//*[@id=\"contact-page\"]/div[2]/div[1]/div/h2")
    public WebElement contactUsMessage; // Message displayed after submitting the contact form
    
    @FindBy(name="submit")
    WebElement submitBtn;
    
    // Method to fill out the contact form and submit it
   
  public void userCanContactUs(String name, String email, String subject, String message) {
    
   // Entering the user's details in the contact form
      nameTxt.sendKeys(name);
      emailTxt.sendKeys(email);
      subjectTxt.sendKeys(subject);
      messageTxt.sendKeys(message);
        
        // Uploading a file (hardcoded file path)
        String filePath = "C:\\Users\\AD\\Downloads\\download.jpg";
       try {
            Thread.sleep(2000); // Wait for 2 seconds before uploading the file
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        uploadFileBtn.sendKeys(filePath); // Send file path to the upload button

        // Clicking the submit button to send the contact form
        submitBtn.click();
        
        // Handling alert if it appears after form submission
        try {
            driver.switchTo().alert().accept(); // Accept the alert if it appears
        } catch (Exception e) {
            System.out.println("No alert was displayed."); // Print message if no alert is displayed
        }
    }
}
