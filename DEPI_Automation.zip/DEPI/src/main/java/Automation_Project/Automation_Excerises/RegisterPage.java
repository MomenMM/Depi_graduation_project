package Automation_Project.Automation_Excerises;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegisterPage extends PageBase {

	
	public RegisterPage(WebDriver driver) {
		super(driver);
	}

	
@FindBy(name = "name")
WebElement usernameTxt; // Username input field
	
@FindBy(name = "email")
List<WebElement> emails; // Email input fields 

@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/button")
WebElement signUpBtn; // Sign-up button

@FindBy(id = "id_gender2")
WebElement femaleGenderBtn; // Female gender radio button

@FindBy(id = "password")
WebElement passwordTxt; // Password input field

@FindBy(id = "days")
WebElement daysList; // Birthdate day dropdown

@FindBy(id = "months") // Birthdate month dropdown
WebElement monthsList; 

@FindBy(id = "years") // Birthdate year dropdown
WebElement yearsList; 

@FindBy(id = "newsletter")
WebElement newsLetterBtn; // Newsletter subscription checkbox

@FindBy(id = "optin")
WebElement specialOfferBtn; // Special offer subscription checkbox

@FindBy(id = "first_name")
WebElement firstNameTxt; // First name input field

@FindBy(id = "last_name")
WebElement lastNameTxt; // Last name input field

@FindBy(id = "company")
WebElement companyTxt; // Company name input field

@FindBy(id = "address1")
WebElement addressTxt1; // Address input field

@FindBy(id = "country")
WebElement countryList; // Country dropdown list

@FindBy(id = "state")
WebElement stateTxt; // State input field

@FindBy(id = "city")
WebElement cityTxt; // City input field

@FindBy(id = "zipcode")
WebElement zipCodeTxt; // Zip code input field

@FindBy(id = "mobile_number")
WebElement mobileNumberTxt; // Mobile number input field

@FindBy(css = "#form > div > div > div > div.login-form > form > button")
WebElement createAccountBtn; // Create account button

@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2/b")
public WebElement successMesssage; // Success message after account creation

@FindBy(linkText = "Continue")
public WebElement continueBtn; // Continue button after account creation

@FindBy(partialLinkText = "Logged in as")
public WebElement loggedInMessage; // Logged-in message after successful login

@FindBy(tagName = "li")
List<WebElement> navBarLinks; // Navigation bar links

 @FindBy(css = "#form > div > div > div:nth-child(3) > div > form > p")
 public WebElement failedMessage; // Error message for failed registration

 @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/h2")
 public WebElement newUserMessage; // New user message after registration

 // Method to fill in the username, email, and click the sign-up button
 public void userCanRegister(String name, String email) {
	 usernameTxt.sendKeys(name);
 if (emails.size() > 1) {
	 emails.get(1).sendKeys(email); // Assumes second field is for signup
		}
		signUpBtn.click(); // Click the sign-up button
	}

	// Method to fill in all the account information during registration
 public void enterAccountInformation(String password, int day, String month, String year, String firstName,
String lastName, String company, String address, String country, String state, String city, String zipCode,
String mobileNumber) {

femaleGenderBtn.click(); // Select female gender
passwordTxt.sendKeys(password); // Enter password

// Select birthdate from dropdowns
Select makeDaysList = new Select(daysList);
Select makeMonthsList = new Select(monthsList);
Select makeYearsList = new Select(yearsList);
Select makeCountryList = new Select(countryList);

 makeDaysList.selectByIndex(day); // Select day
 makeMonthsList.selectByValue(month); // Select month
 makeYearsList.selectByVisibleText(year); // Select year

 newsLetterBtn.click(); // Subscribe to newsletter
specialOfferBtn.click(); // Subscribe to special offers

// Enter personal details
		
firstNameTxt.sendKeys(firstName);
		
lastNameTxt.sendKeys(lastName);
		
companyTxt.sendKeys(company);

addressTxt1.sendKeys(address);
makeCountryList.selectByValue(country); // Select country
// Enter address details
stateTxt.sendKeys(state);
cityTxt.sendKeys(city);
zipCodeTxt.sendKeys(zipCode);
mobileNumberTxt.sendKeys(mobileNumber); // Enter mobile number
createAccountBtn.click(); // Click to create account
	}
	// Check if the "New User" message is visible on the page
public boolean isNewUserMessageVisible() {
try {
return newUserMessage.isDisplayed(); // Check if the new user message is visible
		} catch (Exception e) {
			return false; // Return false if there's an error (message not visible)
		}
	}
	// Check if the account creation success message is visible
public boolean isAccountCreatedMessageVisible() {
try {
			// Check if the success message is displayed
return successMesssage.isDisplayed() && successMesssage.getText().equalsIgnoreCase("Account Created!"); 
																												
		} catch (Exception e) {
			return false; // Return false if there is an error (message not visible)
		}
	}
}
