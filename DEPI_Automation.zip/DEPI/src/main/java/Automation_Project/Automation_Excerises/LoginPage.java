package Automation_Project.Automation_Excerises;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends PageBase {

    
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    // Email input field
    @FindBy(name = "email")
    WebElement emailTxt;

    // Password input field
    @FindBy(name = "password")
    WebElement passwordTxt;

    // Login button inside the login form
    @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/form/button")
    WebElement loginBtn;

    // Message displayed above the login form 
    @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/h2")
    public WebElement loginMessage;

    // Logout button that appears after a successful login
    @FindBy(linkText = "Logout")
    public WebElement logoutBtn;

    // Message shown when login fails 
    @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div[1]/form/p")
    public WebElement failedMessage;

    // Message shown at the top of the login form
    @FindBy(xpath = "//*[contains(text(),'Login to your account')]")
    public WebElement loginToAccountMessage;

    // Confirmation message after login 
    @FindBy(xpath = "//*[contains(text(),'Logged in as')]")
    public WebElement loggedInAsUsername;

    //  the login button visibility check
    @FindBy(xpath = "//*[@id=\"form\"]/div/div/div[1]/div/form/button")
    public WebElement loginButton;

    // Method  log in
    public void userCanLogin(String email, String password) {
        emailTxt.sendKeys(email);
        passwordTxt.sendKeys(password);
        loginBtn.click();  
    }

    // Method to log out account
    public void userCanLogout() {
        logoutBtn.click();  
    }

    // Check if the "Login to your account" message is visible
    public boolean isLoginToAccountMessageVisible() {
        try {
            return loginToAccountMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Check if the "Logged in as username message is visible
    public boolean isLoggedInAsUsernameVisible() {
        try {
            return loggedInAsUsername.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // Check if the login button is displayed 
    public boolean isLoginButtonVisible() {
        try {
            return loginButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
