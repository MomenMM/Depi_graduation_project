package S3Project.The_Automation;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage extends PageBase {

	public CartPage(WebDriver driver) {
		super(driver);
		 
	}

    @FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")
    public WebElement cartBtn;
    
    @FindBy(xpath = "//*[@id=\"product-1\"]/td[4]")
    public WebElement cartquantity;
    
    @FindBy(xpath = "//td[@class='cart_quantity']//button")
    public WebElement cartQuantity;
    
    @FindBy(css = ".cart-item")
    public List<WebElement> cartItems;
    
    @FindBy(xpath = "//*[@id=\"product-1\"]/td[6]/a/i") 
    public WebElement removeButton;
	
    @FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
   public   WebElement viewCartButton;
    
    @FindBy(xpath = "//*[@id=\"product-1\"]/td[4]/button")
    public WebElement quantityInput;
  
    @FindBy(xpath = "//*[@id=\"empty_cart\"]/p/b")
    public WebElement emptyCartMessage;
    
    @FindBy(xpath = "//*[@id=\"do_action\"]/div[1]/div/div/a")
    public WebElement CheckoutBtn;
    
    @FindBy(xpath = "//*[@id=\"checkoutModal\"]/div/div/div[2]/p[2]/a/u")
    public WebElement RegisterAndLoginBtn; 
    
    @FindBy(xpath = "//*[@id=\"cart_items\"]/div/div[2]/h2")
    public WebElement AddressDetailsMsg; 
   
    @FindBy(xpath = "//*[@id=\"ordermsg\"]/textarea")
    public WebElement TextDescriptionArea; 
    
    @FindBy(xpath = "//*[@id=\"cart_items\"]/div/div[7]/a")
    public WebElement PlaceOrderBtn; 
    
    @FindBy(xpath = "//*[@id=\"cart_items\"]/div/div[2]/h2")
    public WebElement PaymentMsg;
    
    
    @FindBy(xpath = "//*[@id=\"payment-form\"]/div[1]/div/input")
    public WebElement NameOnCardTxt; 
    
    @FindBy(xpath = "//*[@id=\"payment-form\"]/div[2]/div/input")
    public WebElement CardNumTxt;
    
    @FindBy(xpath = "//*[@id=\"payment-form\"]/div[3]/div[1]/input")
    public WebElement Cvc;
    
    @FindBy(xpath = "//*[@id=\"payment-form\"]/div[3]/div[2]/input")
    public WebElement ExpirationM;
    
    @FindBy(xpath = "//*[@id=\"payment-form\"]/div[3]/div[3]/input")
    public WebElement ExpirationY;
    
    @FindBy(xpath = "//*[@id=\"submit\"]")
    public WebElement ConfirmOrderBtn;
    
    @FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2/b")
    public WebElement OrderPlacedMsg;
    
    public CartPage clickViewCart() {
        viewCartButton.click();
        return this;
    }
    public CartPage clickCheckOut() {
        CheckoutBtn.click();
        return this;
    }    
    public CartPage clickRegisterBtn() {
        RegisterAndLoginBtn.click();
        return this;
    }
    public CartPage clickPlaceOrder() {
        PlaceOrderBtn.click();
        return this;
    }
        
    public int getCartQuantity() {
        return Integer.parseInt(cartQuantity.getText());
    }
    public void removeProduct() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            WebElement button = wait.until(ExpectedConditions.elementToBeClickable(removeButton));
            button.click();
            System.out.println("Successfully clicked Remove button");
         
            wait.until(ExpectedConditions.stalenessOf(removeButton));  
        } catch (Exception e) {
            System.out.println("Failed to click Remove button: " + e.getMessage());
            throw e;  
        }
    }
    public void checkAndRemoveIfQuantityZero() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            wait.until(ExpectedConditions.visibilityOf(quantityInput));
            String quantityValue = quantityInput.getAttribute("value");
            System.out.println("Quantity attribute value: " + quantityValue);
            int qty = 0;  
            if (quantityValue != null && !quantityValue.trim().isEmpty()) {
                qty = Integer.parseInt(quantityValue.trim());
            }
            if (qty == 0) {
                removeProduct();
                System.out.println("Removed product because quantity is 0");
            }
        } catch (Exception e) {
            System.out.println("Failed to check quantity: " + e.getMessage());
            removeProduct();  
        }
		
    }
  
	 
   
    
    public boolean isCartEmpty() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            return wait.until(ExpectedConditions.visibilityOf(emptyCartMessage)).isDisplayed();
        } catch (Exception e) {
            System.out.println("Failed to find empty cart message: " + e.getMessage());
            return false;
        }
    }
    

	public void EnterDescription(String description) {
		TextDescriptionArea.sendKeys(description);
		 
	}
	public void EnterPayment(String name,String cardNum,String cvc,String Exp,String ExpY) {
		NameOnCardTxt.sendKeys(name);
		CardNumTxt.sendKeys(cardNum);
		Cvc.sendKeys(cvc);
		ExpirationM.sendKeys(Exp);
		ExpirationY.sendKeys(ExpY);
		ConfirmOrderBtn.click();
	}
	 
    
}
