package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Autoamtion_Project.Automation_Excericse.HomePage;
import Autoamtion_Project.Automation_Excericse.ProductPage;
import Autoamtion_Project.Automation_Excericse.CartPage;
import Autoamtion_Project.Automation_Excericse.LoginPage; 

import java.time.Duration;
import java.util.List; 


public class TestCase20 {

    private WebDriver driver;
    private HomePage homePage;
    private ProductPage productPage;
    private CartPage cartPage;
    private LoginPage loginPage; 

    // Define test data
    private final String SEARCH_PRODUCT_NAME = "Blue Top"; 
    private final String TEST_EMAIL = "ahmedlotfy@gmail.com"; 
    private final String TEST_PASSWORD = "123456"; 

    @BeforeClass
    public void setup() {
        
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();

        
        driver.manage().window().maximize();
      
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

       
        homePage = new HomePage(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
        loginPage = new LoginPage(driver); 
    }

    @Test
    public void searchProductsAndVerifyCartAfterLoginTest() {
        
        driver.get("https://automationexercise.com");

      
        Assert.assertTrue(homePage.isHomePageVisible(), "Home page is not visible.");

        
        productPage = homePage.clickProducts();

        
        Assert.assertTrue(productPage.isAllProductsTitleVisible(), "Not navigated to ALL PRODUCTS page.");

        
        productPage.enterSearchInput(SEARCH_PRODUCT_NAME);
        productPage.clickSearchButton();

       
        Assert.assertTrue(productPage.isSearchedProductsTitleVisible(), "'SEARCHED PRODUCTS' title is not visible.");

       
        List<WebElement> searchedProducts = productPage.getDisplayedProducts();
        Assert.assertFalse(searchedProducts.isEmpty(), "No products found for the search query.");
        System.out.println("Found " + searchedProducts.size() + " products for search query: " + SEARCH_PRODUCT_NAME);


      
        productPage.addAllDisplayedProductsToCart();
        System.out.println("Added all searched products to cart.");

        
        cartPage = homePage.clickCart();
        Assert.assertTrue(cartPage.isCartTableVisible(), "Cart page is not visible.");
        Assert.assertTrue(cartPage.isProductInCart(), "Products are not visible in the cart after adding.");

        
        List<String> productNamesBeforeLogin = cartPage.getProductNamesInCart();
        Assert.assertFalse(productNamesBeforeLogin.isEmpty(), "No product names found in cart before login.");
        System.out.println("Products in cart before login: " + productNamesBeforeLogin);


        
        loginPage = homePage.clickSignupLogin();
        Assert.assertTrue(loginPage.isLoginFormVisible(), "Login page is not visible.");

        
        loginPage.userCanLogin(TEST_EMAIL, TEST_PASSWORD); 

         Assert.assertTrue(homePage.isHomePageVisible(), "Not redirected to Home page after login.");
         
        cartPage = homePage.clickCart(); 
        Assert.assertTrue(cartPage.isCartTableVisible(), "Cart page is not visible after login.");


      
        Assert.assertTrue(cartPage.isProductInCart(), "Products are not visible in the cart after login.");

        
        List<String> productNamesAfterLogin = cartPage.getProductNamesInCart();
        System.out.println("Products in cart after login: " + productNamesAfterLogin);

        
        Assert.assertEquals(productNamesAfterLogin.size(), productNamesBeforeLogin.size(), "Number of items in cart changed after login.");

        
        for (String productName : productNamesBeforeLogin) {
            Assert.assertTrue(cartPage.isProductPresentInCart(productName), "Product '" + productName + "' is not present in cart after login.");
        }

        System.out.println("Test Case 20 Passed: Verified search products and cart persistence after login.");
    }

    @AfterClass
    public void closeBrowser() {
       
            driver.quit();
            
        }
    
    }