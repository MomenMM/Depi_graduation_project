package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Autoamtion_Project.Automation_Excericse.HomePage;
import Autoamtion_Project.Automation_Excericse.ProductPage;
import Autoamtion_Project.Automation_Excericse.BrandPage; 

import java.time.Duration;
import java.util.List; 

public class TestCase19 {

    private WebDriver driver;
    private HomePage homePage;
    private ProductPage productPage;
    private BrandPage brandPage; 

    @BeforeClass
    public void setup() {
       
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();

       
        driver.manage().window().maximize();
       
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        
        homePage = new HomePage(driver);
        productPage = new ProductPage(driver);
        
    }

    @Test
    public void viewBrandProductsTest() {
        
        driver.get("https://automationexercise.com");

        
        homePage.clickProducts();

        
        Assert.assertTrue(productPage.isBrandsSectionVisible(), "Brands section is not visible on the products page.");

        
        List<String> brandNames = productPage.getBrandNames();
        Assert.assertFalse(brandNames.isEmpty(), "No brands found in the brands list.");

       
        String firstBrandName = brandNames.get(0);
        System.out.println("Clicking on brand: " + firstBrandName);
        brandPage = productPage.clickBrand(firstBrandName); 

        Assert.assertTrue(brandPage.isBrandTitleDisplayed(), "Brand page title is not displayed for " + firstBrandName);
        Assert.assertTrue(brandPage.getBrandTitleText().contains(firstBrandName.toUpperCase()),
                "Brand page title does not contain the correct brand name for " + firstBrandName);
        Assert.assertTrue(brandPage.areBrandProductsDisplayed(), "Products are not displayed on the " + firstBrandName + " brand page.");
        
        homePage.clickProducts();
        
        productPage = new ProductPage(driver); 

        String secondBrandName = null;
        if (brandNames.size() > 1) {
             secondBrandName = brandNames.get(1); 
             System.out.println("Clicking on another brand: " + secondBrandName);
             brandPage = productPage.clickBrand(secondBrandName); 
        } else {
             System.out.println("Only one brand found. Skipping clicking a second brand.");
            
             return; 
        }

        Assert.assertTrue(brandPage.isBrandTitleDisplayed(), "Brand page title is not displayed for " + secondBrandName);
        Assert.assertTrue(brandPage.getBrandTitleText().contains(secondBrandName.toUpperCase()),
                "Brand page title does not contain the correct brand name for " + secondBrandName);
        Assert.assertTrue(brandPage.areBrandProductsDisplayed(), "Products are not displayed on the " + secondBrandName + " brand page.");

        System.out.println("Test Case 19 Passed: Verified brand products display.");
    }

    @AfterClass
    public void closeBrowser() {
        
            driver.quit();
        }
    }

