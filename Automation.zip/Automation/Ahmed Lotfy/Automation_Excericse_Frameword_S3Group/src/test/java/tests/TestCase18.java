package tests;

import Autoamtion_Project.Automation_Excericse.HomePage;
import Autoamtion_Project.Automation_Excericse.CategoryPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class TestCase18 {

    private WebDriver driver;
    private HomePage homePage;
    private CategoryPage categoryPage;
    private WebDriverWait wait;

    @BeforeClass
    public void setup() {
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        driver.get("https://www.automationexercise.com/");

       
        homePage = new HomePage(driver);
        categoryPage = new CategoryPage(driver); 
    }

    @Test
    public void viewCategoryProductsAndVerifyTitle() {
        
        wait.until(ExpectedConditions.urlToBe("https://www.automationexercise.com/"));

        Assert.assertTrue(homePage.isHomePageVisible(), "Home page is not visible.");

        Assert.assertTrue(homePage.isCategorySectionVisible(), "Categories section is not visible on the homepage.");

        homePage.expandWomenCategory();

        CategoryPage womenDressPage = homePage.clickWomenSubCategory("Dress");

        Assert.assertTrue(womenDressPage.isCategoryTitleDisplayed(), "Category title 'WOMEN - DRESS PRODUCTS' is not displayed.");
        
        womenDressPage.verifyCategoryTitle("WOMEN -  DRESS PRODUCTS");
  
        driver.get("https://www.automationexercise.com/");
        
        homePage = new HomePage(driver); 
        wait.until(ExpectedConditions.urlToBe("https://www.automationexercise.com/")); 

        
        homePage.expandMenCategory();

        
        CategoryPage menJeansPage = homePage.clickMenSubCategory("Jeans");

       
        Assert.assertTrue(menJeansPage.isCategoryTitleDisplayed(), "Category title 'MEN - JEANS PRODUCTS' is not displayed.");
        
        menJeansPage.verifyCategoryTitle("MEN -  JEANS PRODUCTS");

        System.out.println("Test Case 18 Passed: Verified category products display.");
    }

    @AfterClass
    public void closeBrowser() {
     
            driver.quit();
        }
    }

