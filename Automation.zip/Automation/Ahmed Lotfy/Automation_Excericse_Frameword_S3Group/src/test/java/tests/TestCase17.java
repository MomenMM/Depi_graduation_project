package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Autoamtion_Project.Automation_Excericse.CartPage;
import Autoamtion_Project.Automation_Excericse.HomePage;
import Autoamtion_Project.Automation_Excericse.ProductPage;

public class TestCase17 {
	
	WebDriver driver;
    HomePage homePage;
    ProductPage productPage;
    CartPage cartPage;

    @BeforeClass
    public void setup() {
    	
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        
        driver.manage().window().maximize();
        homePage = new HomePage(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
        
    }
    @Test 
    public void removeProductFromCartTest() throws InterruptedException {

        driver.get("https://automationexercise.com");

       
        homePage.clickProducts(); 
        
       
        productPage.hoverAndAddFirstProductToCart();
        productPage.clickViewCart();

       
        Assert.assertTrue(cartPage.isProductInCart(), "Product was not added to cart.");

        cartPage.clickDelete();

        
        Assert.assertTrue(cartPage.isCartEmpty(), "Product was not removed from cart.");
    }

    @AfterClass
    public void closeBrowser() {
       
        driver.quit();
    }
    
}