package Autoamtion_Project.Automation_Excericse;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class BrandPage extends PageBase {

    private WebDriverWait wait; 

    @FindBy(css = ".features_items .title")
    WebElement brandPageTitle;

    @FindBy(css = ".features_items .productinfo")
    List<WebElement> brandProducts;

    
    public BrandPage(WebDriver driver) {
    	
        super(driver);
        
        PageFactory.initElements(this.driver, this);
       
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(2)); 
    }
    
    public boolean isBrandTitleDisplayed() {
        try {
            
            wait.until(ExpectedConditions.visibilityOf(brandPageTitle));
            return brandPageTitle.isDisplayed();
        } catch (Exception e) {
            
            return false;
        }
    }

   
    public String getBrandTitleText() {
        
        wait.until(ExpectedConditions.visibilityOf(brandPageTitle));
        return brandPageTitle.getText().trim();
    }

   
    public boolean areBrandProductsDisplayed() {
        try {
            
            wait.until(ExpectedConditions.visibilityOfAllElements(brandProducts));
            
            return !brandProducts.isEmpty();
        } catch (Exception e) {
            
            return false;
        }
    }
}
