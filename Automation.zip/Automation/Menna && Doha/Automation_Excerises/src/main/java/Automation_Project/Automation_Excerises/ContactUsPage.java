package Automation_Project.Automation_Excerises;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ContactUsPage extends PageBase {

	public ContactUsPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(name="name")
	WebElement nameTxt;
	
	@FindBy(name="email")
	WebElement emailTxt;
	
	@FindBy(name="subject")
	WebElement subjectTxt;
	
	@FindBy(name="message")
	WebElement messageTxt;
	
	@FindBy(name="upload_file")
	WebElement uploadFileBtn;
	
	@FindBy(xpath="//*[@id=\"contact-page\"]/div[2]/div[1]/div/h2")
	public WebElement contactUsMessage;
	
	@FindBy(name="submit")
	WebElement submitBtn;
	
	public void userCanContactUs(String name,String email,String subject,String message)
	{
		nameTxt.sendKeys(name);
		emailTxt.sendKeys(email);
		
		subjectTxt.sendKeys(subject);
		messageTxt.sendKeys(message);
		
		////// upload file
		String filePath = "C:\\Users\\AD\\Downloads\\download.jpg";
		try {
		    Thread.sleep(2000);
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}

		uploadFileBtn.sendKeys(filePath);

	
		submitBtn.click();
	
	
	try {
	    driver.switchTo().alert().accept(); 
	} catch (Exception e) {
	    System.out.println("No alert was displayed.");
	}

	

	
	}
}
