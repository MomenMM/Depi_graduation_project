
package Automation_Project.Automation_Excerises;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

public class Register_HappyScenario extends TestBase {

    HomePage homeObject;
    RegisterPage registerObject;

    @BeforeMethod
    public void setupPages() {
        homeObject = new HomePage(driver);
        registerObject = new RegisterPage(driver);
    }

    @Test
    public void testRegister_NewUserName_MandatoryAndOptional() throws InterruptedException {
        Thread.sleep(2000);
        homeObject.openRegisterationPage();
        Thread.sleep(2000);

        registerObject.userCanRegister("Menna2001", "menna2001@gmail.com");
        Thread.sleep(2000);

        registerObject.enterAccountInformation(
            "m345@", 6, "2", "2003",
            "Menna", "abdalmoaty", "canonical", "123 Street",
            "India", "Giza", "6october", "15745",
            "01158078778"
        );
        Thread.sleep(2000);
    }
}
