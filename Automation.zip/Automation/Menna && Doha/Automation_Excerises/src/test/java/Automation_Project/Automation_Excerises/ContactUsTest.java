package Automation_Project.Automation_Excerises;

import Automation_Project.Automation_Excerises.ContactUsPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class ContactUsTest {

    WebDriver driver;
    ContactUsPage contactUsPage;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://automationexercise.com/contact_us"); 
        contactUsPage = new ContactUsPage(driver);
    }

    @Test
    public void testUserCanContactUsSuccessfully() {
        contactUsPage.userCanContactUs("Doha", "doha@gmail.com", "Automation Test", "This is a test message from Doha.");
        
 
        Assert.assertTrue(contactUsPage.contactUsMessage.isDisplayed(), "Contact message is not displayed!");
    }

    @AfterClass
    public void CloseBrowser() {
        driver.quit();
    }
}
