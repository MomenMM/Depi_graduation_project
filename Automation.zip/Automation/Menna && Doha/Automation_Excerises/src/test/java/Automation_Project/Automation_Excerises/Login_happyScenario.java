package Automation_Project.Automation_Excerises;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_happyScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);
    @Test (priority = 1)
   public void userCanLoginAndLogoutSuccessfully() throws InterruptedException {
    	Thread.sleep(1000);
    	homeObject.openLoginPage();
    	
    	Thread.sleep(1000);
    	
    	Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
    	
    	loginObject.userCanLogin("menna1204@gamil.com", "mmm23");
    	Thread.sleep(1000);

    	Assert.assertEquals("Logout", loginObject.logoutBtn.getText());
    	
    	loginObject.userCanLogout();
    	Thread.sleep(1000);
    }
}