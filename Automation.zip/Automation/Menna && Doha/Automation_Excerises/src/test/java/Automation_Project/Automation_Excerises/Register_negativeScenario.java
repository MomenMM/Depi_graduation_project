package Automation_Project.Automation_Excerises;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.RegisterPage;

public class Register_negativeScenario extends TestBase {

    HomePage homeObject;
    RegisterPage registerObject;

    @BeforeMethod
    public void setupPages() {
        homeObject = new HomePage(driver);
        registerObject = new RegisterPage(driver);
    }

    @Test
    public void testRegister_ExistEmail() throws InterruptedException {
        Assert.assertEquals(homeObject.homeLink.getCssValue("color"), "rgba(255, 165, 0, 1)");
        Thread.sleep(1000);

        homeObject.openRegisterationPage();
        Thread.sleep(1000);

        Assert.assertEquals(registerObject.newUserMessage.getText(), "New User Signup!");
        
        registerObject.userCanRegister("Mennaallah66", "menna1204@gamil.com");
        Thread.sleep(1000);

        Assert.assertEquals(registerObject.failedMessage.getText(), "Email Address already exist!");
    }
}
