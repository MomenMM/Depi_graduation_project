package Automation_Project.Automation_Excerises;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

@Test
public class Login_negativeScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);
	
     public void userCanLoginAndLogoutSuccessfully()
 throws InterruptedException {
    	Thread.sleep(1000);
    	homeObject.openLoginPage();
    	
    	Thread.sleep(1000);
    	
    	Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
    	
    	loginObject.userCanLogin("menna1284@gamil.com", "mmm");
    	Thread.sleep(1000);

    	Assert.assertEquals("Your email or password is incorrect!", loginObject.failedMessage.getText());
    	
    }
}