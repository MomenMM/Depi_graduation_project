package S3Project.The_Automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductsPage  extends PageBase{
	 
	public ProductsPage(WebDriver driver) {
		super(driver);
	 
		 
	}
	

	@FindBy(id="quantity")
	WebElement QuantityInput;
	
	@FindBy(xpath ="/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")
	public  WebElement AddToCartBtn;
	
	 @FindBy(css = "#cartModal > div > div > div.modal-body > p:nth-child(2) > a > u")
     public WebElement viewCartButton;
	
	 
	
	public boolean isProductDetailPageVisible() {
        return isElementVisible(QuantityInput);
        
    }
	 
	
	
	public ProductsPage setQuantity(int quantity) {
        QuantityInput.clear(); 
        QuantityInput.sendKeys(String.valueOf(quantity)); // Enter new quantity
        return this; 
    }
	public ProductsPage clickAddToCart() {
        AddToCartBtn.click();
        return new ProductsPage(driver);
    }

	 public void clickViewCart() {
	        viewCartButton.click();
	       
	    }
	 
	
}
