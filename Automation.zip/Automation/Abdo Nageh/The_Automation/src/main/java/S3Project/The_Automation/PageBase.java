package S3Project.The_Automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class PageBase {
	protected static WebDriver driver;
	
	public PageBase(WebDriver driver){
		PageBase.driver = driver;
		PageFactory.initElements(driver, this);
	}
	protected static boolean isElementVisible(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
	}
}
