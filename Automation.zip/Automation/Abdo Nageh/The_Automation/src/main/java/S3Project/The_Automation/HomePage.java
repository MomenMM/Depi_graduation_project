package S3Project.The_Automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import sun.nio.ch.WEPollSelectorProvider;

public class HomePage extends PageBase {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	
	@FindBy(linkText = "Home")
	public static WebElement homeLink;
	
	
	@FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li")
	public static
	WebElement viewProductBtn;
	
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")
	public  WebElement cartLink;
	
	@FindBy(linkText = "Signup / Login")
	WebElement signUpBtn;
	                 
	public static boolean isHomePageVisible() {
        return isElementVisible(homeLink);
    }
	
	
	public static ProductsPage clickViewProduct() {
        viewProductBtn.click();
        return new ProductsPage(driver);
    }
	
	public CartPage goToCart() {
        cartLink.click();
        return new CartPage(driver);
    }
 
	public void openRegisterationPage() {
		signUpBtn.click();
	}
	 
	public void openLoginPage() {
		signUpBtn.click();
	}
}