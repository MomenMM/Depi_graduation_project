package S3Project.The_Automation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class EmptyCartAfterLogin extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ProductsPage productsObject = new ProductsPage(driver); 
	CartPage cartObject = new CartPage(driver);
	RegisterPage registerObject = new RegisterPage(driver); 
	LoginPage loginObject = new LoginPage(driver); 
  @Test
  public void EmptyCartAfterLogin() {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
	  	homeObject.openLoginPage();
	  	Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
	  	loginObject.userCanLogin("abdonageh6655@gmail.com", "01234");
	  	Assert.assertEquals("Logged in as Abdo Nageh", registerObject.loggedInMessage.getText());
	  	 homeObject.goToCart();
		  Assert.assertEquals( "Cart is empty!", cartObject.emptyCartMessage.getText());
  }
}
