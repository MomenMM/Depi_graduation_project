package S3Project.The_Automation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterWitnInvalidPassword extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ProductsPage productsObject = new ProductsPage(driver); 
	CartPage cartObject = new CartPage(driver);
	RegisterPage registerObject = new RegisterPage(driver); 
	@Test
	public void  RegisterWitnInvalidPassword() {

		Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
		homeObject.openRegisterationPage(); 

		Assert.assertEquals("New User Signup!", registerObject.newUserMessage.getText());

		registerObject.userCanRegister("abdonageh123","abdelrahmannageh05980@gmail.com");

		Assert.assertEquals("ENTER ACCOUNT INFORMATION", registerObject.enterAccountMessage.getText());

		registerObject.enterAccountInformation("book",1,"10","2003","Abdelrahman","Nageh","Itworx","Zayed","United States","aaaa","bbbb","2164","01012465987");


		String success = "Account Created!";
		Assert.assertEquals(success.toUpperCase(), registerObject.successMesssage.getText());

		registerObject.continueAccount();
	}
}
