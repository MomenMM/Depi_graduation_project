package S3Project.The_Automation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

 

public class Verify_QuantityInCart extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ProductsPage productsObject = new ProductsPage(driver); 
	CartPage cartObject = new CartPage(driver);
	 
  @Test
  public void test_QuantityInCart() {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
	  homeObject.clickViewProduct();
	  Assert.assertTrue(productsObject.isProductDetailPageVisible(), "Product detail page did not open");
	  productsObject.setQuantity(4).clickAddToCart(); 
	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a"))).click();
	  Assert.assertEquals(cartObject.getCartQuantity(),4, "Quantity in cart is not 4");
	 
	 
  }

 
}
