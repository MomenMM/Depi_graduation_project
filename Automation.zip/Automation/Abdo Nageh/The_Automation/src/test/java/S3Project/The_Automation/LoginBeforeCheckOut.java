package S3Project.The_Automation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class  LoginBeforeCheckOut extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ProductsPage productsObject = new ProductsPage(driver); 
	CartPage cartObject = new CartPage(driver);
	RegisterPage registerObject = new RegisterPage(driver); 
	LoginPage loginObject = new LoginPage(driver); 
  @Test
  public void LoginBeforeCheckOut() throws InterruptedException {
	  Assert.assertTrue(homeObject.isHomePageVisible(), "Home page is not visible");
  	homeObject.openLoginPage();
  	Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
  	loginObject.userCanLogin("abdonageh665@gmail.com", "123456");
  	Assert.assertEquals("Logged in as abdo", registerObject.loggedInMessage.getText());
	  homeObject.clickViewProduct();
	  Assert.assertTrue(productsObject.isProductDetailPageVisible(), "Product detail page did not open");
	  productsObject.setQuantity(1).clickAddToCart(); 
	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a"))).click();
	  Assert.assertEquals(cartObject.getCartQuantity(),1, "Quantity in cart is not 1");
	  cartObject.clickCheckOut();
	  Assert.assertEquals("Address Details", cartObject.AddressDetailsMsg.getText());
	  cartObject.EnterDescription("Make It Fast");
	  cartObject.clickPlaceOrder();
	  Assert.assertEquals("PaymentOnline payment solutions", cartObject.PaymentMsg.getText());
	  cartObject.EnterPayment("AbdoNageh","86542145","689","05","2029");
	  Thread.sleep(3000);
	  Assert.assertEquals("ORDER PLACED!", cartObject.OrderPlacedMsg.getText());
	  registerObject.deleteAccount();
	  Assert.assertTrue(registerObject.deleteMessage.getText().equalsIgnoreCase("Account Deleted!"));
   
  }
}
