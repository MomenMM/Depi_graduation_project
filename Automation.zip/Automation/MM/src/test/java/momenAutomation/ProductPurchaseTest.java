package momenAutomation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import java.time.Duration;
import java.util.List;

public class ProductPurchaseTest {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
    String URL = "https://automationexercise.com/";

    // User Details
    String name = "hello";
    String emailPrefix = "meow";
    String emailDomain = "@meow.murr";
    String password = "gamed";
    String firstName = "hello";
    String lastName = "world";
    String address1 = "1 gamed street";
    String country = "Singapore";
    String state = "somestate";
    String city = "somecity";
    String zipcode = "12345";
    String mobileNumber = "1234567891";
    String dobDay = "1";
    String dobMonth = "1"; // January
    String dobYear = "2001";

    // Payment Details
    String cardName = "hello world";
    String cardNumber = "4111222233334444";
    String cardCVC = "123";
    String cardExpiryMonth = "12";
    String cardExpiryYear = "2030";

    @BeforeTest
    public void openBrowser() {

        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(1));
        js = (JavascriptExecutor) driver;
        driver.navigate().to(URL);
    }

    @Test
    public void registerUserAndCompleteOrderWorkflow() {
        String uniqueEmail = emailPrefix + System.currentTimeMillis() + emailDomain;

        // 1. Verify Home page
        assertEquals(driver.getTitle(), "Automation Exercise", "Homepage title does not match.");

        // 2. Click 'Signup / Login'
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/login']"))).click();

        // 3. Verify 'New User Signup!'
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='New User Signup!']")));

        // 4. Enter name and email
        driver.findElement(By.xpath("//input[@data-qa='signup-name']")).sendKeys(name);
        driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(uniqueEmail);

        // 5. Click 'Signup'
        driver.findElement(By.xpath("//button[@data-qa='signup-button']")).click();

        // 6. Verify 'ENTER ACCOUNT INFORMATION'
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[text()='Enter Account Information']")));

        // 7. Fill account details
        driver.findElement(By.id("id_gender1")).click(); // Mr.
        driver.findElement(By.xpath("//input[@data-qa='password']")).sendKeys(password);
        new Select(driver.findElement(By.xpath("//select[@data-qa='days']"))).selectByValue(dobDay);
        new Select(driver.findElement(By.xpath("//select[@data-qa='months']"))).selectByValue(dobMonth);
        new Select(driver.findElement(By.xpath("//select[@data-qa='years']"))).selectByValue(dobYear);

        // 10. Fill address details
        driver.findElement(By.xpath("//input[@data-qa='first_name']")).sendKeys(firstName);
        driver.findElement(By.xpath("//input[@data-qa='last_name']")).sendKeys(lastName);
        driver.findElement(By.xpath("//input[@data-qa='address']")).sendKeys(address1);
        new Select(driver.findElement(By.xpath("//select[@data-qa='country']"))).selectByValue(country);
        driver.findElement(By.xpath("//input[@data-qa='state']")).sendKeys(state);
        driver.findElement(By.xpath("//input[@data-qa='city']")).sendKeys(city);
        driver.findElement(By.xpath("//input[@data-qa='zipcode']")).sendKeys(zipcode);
        driver.findElement(By.xpath("//input[@data-qa='mobile_number']")).sendKeys(mobileNumber);

        // 11. Click 'Create Account'
        WebElement createAccountButton = driver.findElement(By.xpath("//button[@data-qa='create-account']"));
        js.executeScript("arguments[0].scrollIntoView(true);", createAccountButton);
        createAccountButton.click();

        // 12. Verify 'ACCOUNT CREATED!'
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-qa='account-created']/b[text()='Account Created!']")));

        // 13. Click 'Continue'
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();


        // 14. Verify 'Logged in as username'
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-user']")));
        WebElement loggedInAsUser = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(), 'Logged in as')]/b[text()='" + name + "']")));
        assertTrue(loggedInAsUser.isDisplayed(), "'Logged in as " + name + "' is not visible.");

        // 15. Add product to cart
        js.executeScript("window.scrollBy(0,500)", "");
        WebElement addToCartProd1 = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//a[@data-product-id='1' and contains(@class, 'add-to-cart')])[1]")
        ));
        js.executeScript("arguments[0].click();", addToCartProd1);

        // 16. Click 'Continue Shopping' on modal
        WebElement continueShoppingButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//button[contains(@class, 'close-modal') and normalize-space()='Continue Shopping']")
        ));
        continueShoppingButton.click();

        // 17. Click 'Cart' in header
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='shop-menu pull-right']//a[@href='/view_cart']"))).click();

        // 18. Verify product in cart
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("product-1")));
        assertTrue(driver.findElement(By.xpath("//td[@class='cart_description']/h4/a[@href='/product_details/1' and text()='Blue Top']")).isDisplayed(),
                     "Product 'Blue Top' not found in cart.");

        // 19. Click 'Proceed To Checkout'
        driver.findElement(By.xpath("//a[contains(@class, 'check_out') and normalize-space()='Proceed To Checkout']")).click();

        // 20. Verify Address Details
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("address_delivery")));
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_firstname address_lastname']")).getText(), "Mr. " + firstName + " " + lastName);
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_address1 address_address2'][2]")).getText(), address1);
        // ... (other address assertions can be added back if needed for full verification)

        // 21. Click "Place Order"
        WebElement placeOrderButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//a[@href='/payment' and contains(normalize-space(), 'Place Order')]")
        ));
        js.executeScript("arguments[0].scrollIntoView(true);", placeOrderButton);
        placeOrderButton.click();

        // 22. Fill payment details
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@data-qa='name-on-card']")));
        driver.findElement(By.xpath("//input[@data-qa='name-on-card']")).sendKeys(cardName);
        driver.findElement(By.xpath("//input[@data-qa='card-number']")).sendKeys(cardNumber);
        driver.findElement(By.xpath("//input[@data-qa='cvc']")).sendKeys(cardCVC);
        driver.findElement(By.xpath("//input[@data-qa='expiry-month']")).sendKeys(cardExpiryMonth);
        driver.findElement(By.xpath("//input[@data-qa='expiry-year']")).sendKeys(cardExpiryYear);

        // 23. Click "Pay and Confirm Order"
        WebElement payAndConfirmButton = driver.findElement(By.xpath("//button[@data-qa='pay-button']"));
        js.executeScript("arguments[0].scrollIntoView(true);", payAndConfirmButton);
        payAndConfirmButton.click();

        // 24. Verify "Order Placed!"
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-qa='order-placed']/b[text()='Order Placed!']")));
        System.out.println("Order Placed! message verified.");

        // 25. Click "Download Invoice"
        // MODIFIED XPATH to be more flexible with the invoice number in href
        WebElement downloadInvoiceButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//a[starts-with(@href, '/download_invoice/') and contains(@class, 'check_out') and normalize-space()='Download Invoice']")
        ));
        downloadInvoiceButton.click();
        System.out.println("Clicked Download Invoice button.");

        // 26. Click "Continue" after order
        WebElement continueAfterOrderButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//a[@data-qa='continue-button' and @href='/' and contains(@class, 'btn-primary')]")
        ));
        continueAfterOrderButton.click();
        System.out.println("Clicked Continue button after order.");

        // 27. Click 'Delete Account'
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/delete_account']"))).click();

        // 28. Verify 'ACCOUNT DELETED!'
        driver.switchTo().defaultContent(); // Ensure not stuck in an ad iframe
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-qa='account-deleted']/b[text()='Account Deleted!']")));
        System.out.println("Account Deleted! message verified.");

        // 29. Click 'Continue'
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();

        // 30. Final verification: Logged out
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/login']")));
        System.out.println("Test completed successfully! User is logged out.");
    }

    @AfterTest
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}
