package momenAutomation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import java.time.Duration;

public class RecommendedItemsTest {

    WebDriver driver;
    String URL = "https://automationexercise.com/";
    WebDriverWait wait; // Explicit wait

    @BeforeTest
    public void openBrowser() {

        driver = new FirefoxDriver();
        driver.manage().window().maximize(); // Maximize browser window
        // Initialize WebDriverWait with a timeout of 10 seconds
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.navigate().to(URL); // Navigate to the base URL
    }

    @Test(priority = 1)
    public void verifyHomePageTitle() {
        // Verify the title of the homepage
        String title = driver.getTitle();
        assertEquals(title, "Automation Exercise", "Homepage title does not match.");
    }

    @Test(priority = 2)
    public void addRecommendedItemToCartAndVerify() throws InterruptedException {
        // Test case for adding a recommended item to the cart and verifying it

        // 1. Scroll to the bottom of the page
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(1000); // Give time for any lazy-loaded elements to appear

        // 2. Verify 'RECOMMENDED ITEMS' are visible
        // Locate the "recommended items" header
        WebElement recommendedItemsHeader = driver.findElement(By.xpath("//h2[@class='title text-center' and normalize-space()='recommended items']"));
        // Scroll the header into view if it's not immediately visible after the initial scroll
        js.executeScript("arguments[0].scrollIntoView(true);", recommendedItemsHeader);
        assertTrue(recommendedItemsHeader.isDisplayed(), "'recommended items' header is not visible.");

        // 3. Click on 'Add To Cart' on a recommended product (e.g., product-id="1")
        // Locate the "Add to cart" button for product ID 1 within the recommended items section
        // It's important to ensure this XPath is specific enough to the recommended items section
        // The website structure might have multiple "Add to cart" buttons with the same product ID
        // This XPath targets the button within the 'recommended_items' div
        WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//div[@class='recommended_items']//a[@data-product-id='1' and contains(@class, 'add-to-cart')]")
        ));
        // Scroll to the button before clicking to ensure it's clickable
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", addToCartButton);
        addToCartButton.click();

        // 4. Click on 'View Cart' button in the modal
        // Wait for the modal to appear and the 'View Cart' link to be clickable
        WebElement viewCartLink = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//div[contains(@class, 'modal-content')]//a[@href='/view_cart']/u[text()='View Cart']")
        ));
        viewCartLink.click();

        // 5. Verify that product is displayed in cart page
        // Wait for the cart page to load and the product row to be present
        WebElement productInCart = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("product-1")));
        assertTrue(productInCart.isDisplayed(), "Product with ID 'product-1' is not displayed in the cart.");

        // Optional: Further verification of product details in the cart
        WebElement productNameInCart = productInCart.findElement(By.xpath(".//td[@class='cart_description']/h4/a[@href='/product_details/1']"));
        assertEquals(productNameInCart.getText().trim(), "Blue Top", "Product name in cart does not match.");

        WebElement productPriceInCart = productInCart.findElement(By.xpath(".//td[@class='cart_price']/p"));
        assertTrue(productPriceInCart.getText().contains("500"), "Product price in cart does not match.");

        WebElement productQuantityInCart = productInCart.findElement(By.xpath(".//td[@class='cart_quantity']/button"));
        assertEquals(productQuantityInCart.getText().trim(), "1", "Product quantity in cart does not match.");
    }

    @AfterTest
    public void closeBrowser() {
        // Closes the browser and ends the WebDriver session
        if (driver != null) {
            driver.quit(); // quit() closes all windows and terminates the session
        }
    }
}
