package momenAutomation;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import java.time.Duration;
import java.util.List;

public class RegPerDel {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
    String URL = "https://automationexercise.com/";

    // User Details - email will be made unique
    String name = "hello";
    String emailPrefix = "meow";
    String emailDomain = "@meow.murr";
    String password = "gamed";
    String firstName = "hello"; // Same as signup name for simplicity
    String lastName = "world";
    String address1 = "1 gamed street";
    String country = "Singapore";
    String state = "somestate";
    String city = "somecity";
    String zipcode = "12345";
    String mobileNumber = "1234567891";
    String dobDay = "1";
    String dobMonth = "1"; // January
    String dobYear = "2001";


    @BeforeTest
    public void openBrowser() {

        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(2)); // Increased wait time for potentially slow pages/ads
        js = (JavascriptExecutor) driver;
        driver.navigate().to(URL);

    }

    @Test
    public void registerUserAndCompleteWorkflow() {
        String uniqueEmail = emailPrefix + System.currentTimeMillis() + emailDomain;

        // 1. Navigate to Home page - already done in @BeforeTest
        assertEquals(driver.getTitle(), "Automation Exercise", "Homepage title does not match.");

        // 2. Click on 'Signup / Login' button
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/login']"))).click();

        // 3. Verify 'New User Signup!' is visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='New User Signup!']")));

        // 4. Enter name and email address
        driver.findElement(By.xpath("//input[@data-qa='signup-name']")).sendKeys(name);
        driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(uniqueEmail);

        // 5. Click 'Signup' button
        driver.findElement(By.xpath("//button[@data-qa='signup-button']")).click();

        // 6. Verify that 'ENTER ACCOUNT INFORMATION' is visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[text()='Enter Account Information']")));

        // 7. Fill details: Title, Password, Date of birth
        driver.findElement(By.id("id_gender1")).click(); // Mr.
        driver.findElement(By.xpath("//input[@data-qa='password']")).sendKeys(password);
        new Select(driver.findElement(By.xpath("//select[@data-qa='days']"))).selectByValue(dobDay);
        new Select(driver.findElement(By.xpath("//select[@data-qa='months']"))).selectByValue(dobMonth);
        new Select(driver.findElement(By.xpath("//select[@data-qa='years']"))).selectByValue(dobYear);

        // 8. Select checkbox 'Sign up for our newsletter!' (Optional, but good practice to interact with all relevant form fields)
        // driver.findElement(By.id("newsletter")).click();

        // 9. Select checkbox 'Receive special offers from our partners!' (Optional)
        // driver.findElement(By.id("optin")).click();

        // 10. Fill details: First name, Last name, Company, Address, Address2, Country, State, City, Zipcode, Mobile Number
        driver.findElement(By.xpath("//input[@data-qa='first_name']")).sendKeys(firstName);
        driver.findElement(By.xpath("//input[@data-qa='last_name']")).sendKeys(lastName);
        // driver.findElement(By.xpath("//input[@data-qa='company']")).sendKeys("Test Company"); // Optional
        driver.findElement(By.xpath("//input[@data-qa='address']")).sendKeys(address1); // Address1
        // driver.findElement(By.xpath("//input[@data-qa='address2']")).sendKeys("Apt 123"); // Address2 (Optional)
        new Select(driver.findElement(By.xpath("//select[@data-qa='country']"))).selectByValue(country);
        driver.findElement(By.xpath("//input[@data-qa='state']")).sendKeys(state);
        driver.findElement(By.xpath("//input[@data-qa='city']")).sendKeys(city);
        driver.findElement(By.xpath("//input[@data-qa='zipcode']")).sendKeys(zipcode);
        driver.findElement(By.xpath("//input[@data-qa='mobile_number']")).sendKeys(mobileNumber);

        // 11. Click 'Create Account button'
        // Scroll to button before clicking as it might be off-screen
        WebElement createAccountButton = driver.findElement(By.xpath("//button[@data-qa='create-account']"));
        js.executeScript("arguments[0].scrollIntoView(true);", createAccountButton);
        createAccountButton.click();

        // 12. Verify that 'ACCOUNT CREATED!' is visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-qa='account-created']/b[text()='Account Created!']")));

        // 13. Click 'Continue' button
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();

        


        // 14. Verify that 'Logged in as username' and user icon is visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class='fa fa-user']")));
        WebElement loggedInAsUser = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(), 'Logged in as')]/b[text()='" + name + "']")));
        assertTrue(loggedInAsUser.isDisplayed(), "'Logged in as " + name + "' is not visible.");

        // 15. Add product to cart (product-id="1")
        // Scroll to ensure the product area is in view
        js.executeScript("window.scrollBy(0,500)", ""); // Scroll down a bit to find products
        WebElement addToCartProd1 = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("(//a[@data-product-id='1' and contains(@class, 'add-to-cart')])[1]") // Get the first one
        ));
        js.executeScript("arguments[0].click();", addToCartProd1); // Use JS click if normal click is intercepted

        // 16. Click 'Continue Shopping' button on the modal
        WebElement continueShoppingButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//button[contains(@class, 'close-modal') and normalize-space()='Continue Shopping']")
        ));
        continueShoppingButton.click();

        // 17. Click on 'Cart' button in header
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='shop-menu pull-right']//a[@href='/view_cart']"))).click();

        // 18. Verify that product is displayed in cart page
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("product-1")));
        assertTrue(driver.findElement(By.xpath("//td[@class='cart_description']/h4/a[@href='/product_details/1' and text()='Blue Top']")).isDisplayed(),
                   "Product 'Blue Top' not found in cart.");

        // 19. Click 'Proceed To Checkout' button
        driver.findElement(By.xpath("//a[contains(@class, 'check_out') and normalize-space()='Proceed To Checkout']")).click();

        // 20. Verify Address Details in checkout page
        // Delivery Address
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("address_delivery")));
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_firstname address_lastname']")).getText(), "Mr. " + firstName + " " + lastName, "Delivery name mismatch.");
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_address1 address_address2'][2]")).getText(), address1, "Delivery address1 mismatch.");
        assertTrue(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_city address_state_name address_postcode']")).getText().contains(city + " " + state + " " + zipcode), "Delivery city/state/zip mismatch.");
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_country_name']")).getText(), country, "Delivery country mismatch.");
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_delivery']/li[@class='address_phone']")).getText(), mobileNumber, "Delivery phone mismatch.");

        // Billing Address (should be same as delivery for this flow)
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_invoice']/li[@class='address_firstname address_lastname']")).getText(), "Mr. " + firstName + " " + lastName, "Billing name mismatch.");
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_invoice']/li[@class='address_address1 address_address2'][2]")).getText(), address1, "Billing address1 mismatch.");
        assertTrue(driver.findElement(By.xpath("//ul[@id='address_invoice']/li[@class='address_city address_state_name address_postcode']")).getText().contains(city + " " + state + " " + zipcode), "Billing city/state/zip mismatch.");
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_invoice']/li[@class='address_country_name']")).getText(), country, "Billing country mismatch.");
        assertEquals(driver.findElement(By.xpath("//ul[@id='address_invoice']/li[@class='address_phone']")).getText(), mobileNumber, "Billing phone mismatch.");

        // 21. Click 'Delete Account' button
        driver.findElement(By.xpath("//a[@href='/delete_account']")).click();

        // 22. Verify that 'ACCOUNT DELETED!' is visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@data-qa='account-deleted']/b[text()='Account Deleted!']")));

        // 23. Click 'Continue' button
        driver.findElement(By.xpath("//a[@data-qa='continue-button']")).click();

        // Final verification: check if user is logged out (e.g., 'Signup / Login' button is visible again)
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/login']")));
        System.out.println("Test completed successfully!");
    }

    @AfterTest
    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}
